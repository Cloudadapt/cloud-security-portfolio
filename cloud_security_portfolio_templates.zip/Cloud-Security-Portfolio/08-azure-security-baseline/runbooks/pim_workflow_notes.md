# Privileged Identity Management (PIM) Workflow Notes

- Eligible vs active role definitions
- Approval flow for elevation
- Justification examples
- Max activation duration
- Review cadence and evidence capture
