### Cloud Security Portfolio
I design and operationalize practical security controls across cloud platforms. This repo shows my approach end to end—governance, IAM, data protection, detection/response, CI/CD security, patching, and zero trust networking.
