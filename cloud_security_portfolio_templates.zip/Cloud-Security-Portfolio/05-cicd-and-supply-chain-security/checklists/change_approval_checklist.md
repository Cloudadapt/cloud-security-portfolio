# Higher‑Risk Change Approval Checklist

- [ ] Linked ticket with risk description and rollback plan
- [ ] Security review completed (attach notes)
- [ ] Tests passed in CI
- [ ] Owner confirms maintenance window (if applicable)
- [ ] Stakeholder notification sent
- [ ] Post‑deployment verification plan attached
