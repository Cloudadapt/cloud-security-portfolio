# Contributing / Hygiene

- Do not commit secrets or sensitive data.
- Redact account IDs and usernames in screenshots.
- Keep templates updated with review dates and owners.
