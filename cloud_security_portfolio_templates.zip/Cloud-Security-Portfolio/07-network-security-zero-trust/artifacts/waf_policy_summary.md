# WAF Policy Summary (Template)

- Managed rulesets enabled (OWASP)
- Rate limiting thresholds
- IP allow/deny lists (if any)
- False positive handling process
- Sample blocked request metrics
