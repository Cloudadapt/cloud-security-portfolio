# Flow Log Analysis Notes (Template)

- Top talkers and ports
- Unexpected egress destinations
- Unused security group rules to remove
- Changes applied and verification notes
