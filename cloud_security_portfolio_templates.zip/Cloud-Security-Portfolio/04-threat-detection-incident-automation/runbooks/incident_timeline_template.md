# Incident Timeline Template

**Date:** 2025-08-24

| Time (UTC) | Actor | Action | Evidence Link |
|---|---|---|---|
|  |  |  |  |

## Post‑Incident
- Root cause:
- Containment:
- Eradication:
- Recovery:
- Lessons learned:
